// ---- Inject CSS dynamically ----
const style = document.createElement("style");
style.textContent = `
body { font-family: Arial, sans-serif; background: #f0f8ff; margin:0; padding:0; }
h1 { text-align: center; background: #0077b6; color:white; padding:15px; margin:0; }
.semester { margin: 20px auto; padding: 20px; max-width: 900px; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
.semester h2 { color:#023e8a; }
.accordion { background:#0096c7; color:white; cursor:pointer; padding:14px; width:100%; text-align:left; border:none; outline:none; font-size:16px; transition:0.3s; margin:5px 0; border-radius:8px; }
.accordion:hover { background:#0077b6; }
.accordion.active { background:#023e8a; }
.panel { background:#f1f9ff; display:none; padding:10px; border-radius:8px; }
.accordion-topic { background:#48cae4; color:white; cursor:pointer; padding:10px; width:95%; text-align:left; border:none; outline:none; font-size:14px; transition:0.3s; margin:5px 10px; border-radius:6px; display:block; }
.accordion-topic:hover { background:#0096c7; }
.accordion-topic.active { background:#0077b6; }
.panel-topic { background:#caf0f8; display:none; margin-left:10px; padding:10px; border-left:3px solid #0077b6; border-radius:6px; }
.panel-topic p { margin:10px 0; line-height:1.5; font-size:14px; }
`;
document.head.appendChild(style);

// ---- Create HTML structure dynamically ----
const subjects = [
  {
    name: "Food & Beverage Service – I",
    topics: [
      {
        title: "Introduction to F&B Service",
        desc: "Definition, scope, importance, role in hotel industry."
      },
      {
        title: "Types of Food Service Operations",
        desc: "Commercial & Welfare Catering explained with examples."
      },
      {
        title: "Food Service Equipment",
        desc:
          "Crockery, Cutlery, Glassware, Flatware – classification, usage & maintenance."
      },
      {
        title: "Types of Menu",
        desc:
          "À la carte, Table d’hôte, Cyclical & Semi-à la carte – examples & advantages."
      },
      {
        title: "Methods of Service",
        desc:
          "Silver, American, Russian, French, Buffet, Gueridon – steps & rules."
      }
    ]
  },
  {
    name: "Housekeeping – I",
    topics: [
      {
        title: "Introduction",
        desc: "Role of housekeeping in hotels & institutions."
      },
      {
        title: "Hotel Types & Rooms",
        desc:
          "Classification of hotels, types of guest rooms & bed arrangements."
      },
      {
        title: "Cleaning Equipment & Agents",
        desc: "Manual & mechanical cleaning equipment, eco-friendly agents."
      },
      {
        title: "Bed Making Procedures",
        desc: "Steps of bed making, turndown service."
      }
    ]
  },
  {
    name: "Front Office – I",
    topics: [
      {
        title: "Introduction",
        desc: "Front office as the nerve center of the hotel."
      },
      {
        title: "Layout of Front Office",
        desc: "Reception, lobby, cashier, bell desk, travel desk."
      },
      {
        title: "Functions",
        desc: "Reservations, registration, guest services, billing, check-out."
      }
    ]
  },
  {
    name: "Food Production – I",
    topics: [
      {
        title: "Introduction to Cookery",
        desc: "Aims & objectives, importance of cooking."
      },
      {
        title: "Culinary Terms",
        desc: "Mise-en-place, mise-en-scène, bouquet garni, roux, etc."
      },
      {
        title: "Kitchen Layout",
        desc: "Main kitchen, satellite kitchen, equipment classification."
      }
    ]
  },
  {
    name: "Communication Skills",
    topics: [
      {
        title: "Basics of Communication",
        desc: "Process, barriers, overcoming methods."
      },
      {
        title: "Grammar",
        desc: "Tenses, prepositions, articles, common errors."
      }
    ]
  },
  {
    name: "Computer Fundamentals",
    topics: [
      { title: "Basics", desc: "History, generations of computers." },
      { title: "MS Office", desc: "Word, Excel, PowerPoint – basic functions." }
    ]
  },
  {
    name: "Food Science & Nutrition",
    topics: [
      {
        title: "Introduction",
        desc: "Importance of food science in hospitality."
      },
      {
        title: "Macronutrients",
        desc: "Carbohydrates, Proteins, Fats – functions & sources."
      },
      {
        title: "Micronutrients",
        desc: "Vitamins & minerals – classification & functions."
      }
    ]
  }
];

// Container
const semesterDiv = document.createElement("div");
semesterDiv.classList.add("semester");
semesterDiv.innerHTML = "<h2>Semester 1</h2>";
document.body.appendChild(semesterDiv);

// Generate subjects & topics
subjects.forEach((sub) => {
  const subBtn = document.createElement("button");
  subBtn.classList.add("accordion");
  subBtn.innerText = sub.name;
  const subPanel = document.createElement("div");
  subPanel.classList.add("panel");

  sub.topics.forEach((top) => {
    const topBtn = document.createElement("button");
    topBtn.classList.add("accordion-topic");
    topBtn.innerText = top.title;
    const topPanel = document.createElement("div");
    topPanel.classList.add("panel-topic");
    topPanel.innerHTML = `<p>${top.desc}</p>`;
    subPanel.appendChild(topBtn);
    subPanel.appendChild(topPanel);
  });

  semesterDiv.appendChild(subBtn);
  semesterDiv.appendChild(subPanel);
});

// ---- JS functionality ----
// Subject toggle
const acc = document.getElementsByClassName("accordion");
for (let i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function () {
    const panel = this.nextElementSibling;
    for (let j = 0; j < acc.length; j++) {
      if (acc[j] !== this) {
        acc[j].classList.remove("active");
        acc[j].nextElementSibling.style.display = "none";
        const topics = acc[j].nextElementSibling.getElementsByClassName(
          "panel-topic"
        );
        for (let t = 0; t < topics.length; t++) {
          topics[t].style.display = "none";
        }
      }
    }
    if (panel.style.display === "block") {
      panel.style.display = "none";
      this.classList.remove("active");
    } else {
      panel.style.display = "block";
      this.classList.add("active");
    }
  });
}

// Topic toggle
const topicAcc = document.getElementsByClassName("accordion-topic");
for (let i = 0; i < topicAcc.length; i++) {
  topicAcc[i].addEventListener("click", function (e) {
    e.stopPropagation();
    const panel = this.nextElementSibling;
    const parent = this.parentElement;
    const allTopics = parent.getElementsByClassName("panel-topic");
    for (let j = 0; j < allTopics.length; j++) {
      if (allTopics[j] !== panel) {
        allTopics[j].style.display = "none";
      }
    }
    if (panel.style.display === "block") {
      panel.style.display = "none";
      this.classList.remove("active");
    } else {
      panel.style.display = "block";
      this.classList.add("active");
    }
  });
}
